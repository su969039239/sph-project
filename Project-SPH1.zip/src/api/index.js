import requests from './request'
import mockRequests from './mockRequest'

export const reqCategoryList = () => requests({ url: '/product/getBaseCategoryList', method: 'get' })

//获取banner(Home)首页轮播图接口
export const reqGetBannerList = () => mockRequests.get('/banner')

//获取floor数据
export const reqGetFloorList = () => mockRequests.get('/floors')

//获取
export const reqGetSearchList = (params) => requests({ url: '/list', method: 'post', data:params})